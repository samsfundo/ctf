
 
Admin
user: admin
pass: admin123


#install
RUN apt-get update && \
    apt-get install -y gnupg gnupg2 gnupg1


# Install CouchDB
#RUN apt-get update && \
 #   apt-get install -y curl && \
 #   apt install pkg-config


RUN apt-key adv --keyserver keyserver.ubuntu.com --recv-keys 8756C4F765C9AC3CB6B85D62379CE192D401AB61

#RUN apt-get update && \
   # apt-get install -y build-essential pkg-config erlang libicu-dev libmozjs185-dev libcurl4-openssl-dev

RUN apt-get update
RUN apt-get install -y software-properties-common



RUN  curl -L https://couchdb.apache.org/repo/bintray-pubkey.asc | apt-key add
RUN apt-key adv --keyserver keyserver.ubuntu.com --recv-keys 8756C4F765C9AC3CB6B85D62379CE192D401AB61


RUN apt update && \
    apt install -y curl apt-transport-https gnupg

RUN curl https://couchdb.apache.org/repo/keys.asc | gpg --dearmor | tee /usr/share/keyrings/couchdb-archive-keyring.gpg >/dev/null 2>&1

#RUN source /etc/os-release
RUN . /etc/os-release && echo $NAME


RUN echo "deb [signed-by=/usr/share/keyrings/couchdb-archive-keyring.gpg] https://apache.jfrog.io/artifactory/couchdb-deb/ ${VERSION_CODENAME} main" \ | tee /etc/apt/sources.list.d/couchdb.list >/dev/null

RUN apt update && \
    apt install -y couchdb


# Add a new user
RUN echo "[admins]" >> /opt/couchdb/etc/local.d/docker.ini
RUN echo "Ayabonga = Ayabonga" >> /opt/couchdb/etc/local.d/docker.ini

# Create a new document
RUN curl -X PUT http://Ayabonga:Ayabonga@localhost:5984/mydatabase
RUN curl -H "Content-Type: application/json" -X POST -d '{"message": "Sifundo is using SifuSifu@123 as a password"}' http://Ayabonga:Ayabonga@localhost:5984/mydatabase

# Start CouchDB
CMD ["/opt/couchdb/bin/couchdb"] && \
CMD ["/bin/bash"]