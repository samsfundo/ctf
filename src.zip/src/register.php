<?php

 include "db_connect.php";

	if(isset($_POST['username']) && isset($_POST['password'])){
        $user = $_POST['username'];
        $password = $_POST['password'];

        $query = "INSERT INTO 'users' (username,password) VALUES('$user','$password')";
        $result = mysqli_query($query,$conn);
        if($result){
            $msg = "Registered Sussecfully";
			echo "Registered Sussecfully";
        }
        else
            $msg = "Error Registering";
			echo "Registered Sussecfully";

    }




?>
