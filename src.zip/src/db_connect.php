<?php 


$conn= new mysqli('127.0.0.1','admin','admin','loan_db')or die("Could not connect to mysql".mysqli_error($con));

?>
